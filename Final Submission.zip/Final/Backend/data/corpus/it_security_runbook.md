# IT Security Runbook

## Passwords
Passwords must be at least 14 characters long and are rotated every 180 days.
Multi-factor authentication (MFA) is mandatory for email, VPN and all SaaS tools.

## Phishing
If you receive a suspicious email, do not click any links. Report it using the "Report Phish" button
or forward it to security@northwind.example within 1 hour.

## Lost or stolen laptop
Call the IT helpdesk immediately on extension 4357. IT will remotely lock and wipe the device.
