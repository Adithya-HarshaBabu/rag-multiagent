# VPN Setup Guide

## Installing
Northwind uses the GlobalProtect VPN client. Install it from the Company Portal app.
Connect to the portal address vpn.northwind.example and sign in with your SSO credentials.

## Troubleshooting
- Error 403 means your device certificate has expired. Re-enrol the device from the Company Portal.
- If the VPN disconnects every few minutes, switch from Wi-Fi 2.4 GHz to 5 GHz or use a wired connection.
- Still stuck? Raise a ticket in ServiceNow under the "Network" category.
